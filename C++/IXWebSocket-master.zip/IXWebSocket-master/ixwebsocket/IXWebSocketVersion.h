/*
 *  IXWebSocketVersion.h
 *  Author: Benjamin Sergeant
 *  Copyright (c) 2019 Machine Zone, Inc. All rights reserved.
 */

#pragma once

#define IX_WEBSOCKET_VERSION "11.4.6"
