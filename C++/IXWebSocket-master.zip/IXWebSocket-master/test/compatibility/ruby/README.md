```
export GEM_HOME=$HOME/local/gems
bundle install faye-websocket
```

https://stackoverflow.com/questions/486995/ruby-equivalent-of-virtualenv
